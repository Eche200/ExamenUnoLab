# Clase 24

### Material

#### Apuntes:

En el directorio "apuntes" se podr�n encontrar los siguientes archivos:
* Creacion_biblioteca_lista.pdf

#### Video tutoriales:

* https://www.youtube.com/watch?v=v-j1xhPH2R4&list=PLZU3OfSJlsrfKiKElmKxjCsyQQF_1ApuV&index=24

### Ejercicio
#### Objetivo:

Agregar a la biblioteca del ejercicio anterior, la posibilidad de borrar un item

- Version: 0.1 del 06 enero de 2016
- Autor: Ernesto Gigliotti
- Revisi�n: Mauricio D�vila

#### Aspectos a destacar:
*  Array de punteros a estructuras creadas en forma din�mica