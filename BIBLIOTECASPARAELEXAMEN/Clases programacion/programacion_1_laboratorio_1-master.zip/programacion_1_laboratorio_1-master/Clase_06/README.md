# Clase 6

### Material

#### Apuntes:

En el directorio "apuntes" se podr�n encontrar los siguientes archivos:
* Cadenas_de_caracteres.pdf

#### Video tutoriales:

* https://www.youtube.com/watch?v=OW1TqB6Xzdw&index=6&list=PLZU3OfSJlsrfKiKElmKxjCsyQQF_1ApuV

### Ejercicio
#### Objetivo:

   1-Agregar a la  biblioteca utn.h  funciones para validar diferentes
     tipos de valores:
       Solo n�meros, ej. 123436679
       Solo letras, ej. abBD
       Alfanumericos, ej. ab555gT6
       Tel�fono, ej. 4XXX-XXXX

   2-Realizar un programa que pida al usuario el ingreso de un dato y
     determine con cuales de los tipos cumple

- Version: 0.1 del 30 diciembre de 2015
- Autor: Mauricio D�vila
- Revisi�n: Ernesto Gigliotti

#### Aspectos a destacar:
*   Manipulaci�n y chequeo de cadena de caracteres