# Clase 20

### Material

#### Apuntes:

En el directorio "apuntes" se podr�n encontrar los siguientes archivos:
* Creacion_lista_dinamica.pdf

#### Video tutoriales:

* https://www.youtube.com/watch?v=Ar8OPMmzYao&index=20&list=PLZU3OfSJlsrfKiKElmKxjCsyQQF_1ApuV

### Ejercicio 1
#### Objetivo:

    Ingresar datos de 1 persona e imprimirlos. Crear la estructura "Persona":
        nombre [32]
        edad
    Si se ingresa �salir� como nombre, se debe salir del programa, de lo contrario se pediran los datos de nuevo.

- Version: 0.1 del 06 enero de 2016
- Autor: Ernesto Gigliotti
- Revisi�n: Mauricio D�vila

#### Aspectos a destacar:
*   Punteros a estructuras

### Ejercicio 2
#### Objetivo:

    Modificar el ejercicio anterior para guardar las personas en un array estatico e imprimirlas al salir

- Version: 0.1 del 06 enero de 2016
- Autor: Ernesto Gigliotti
- Revisi�n: Mauricio D�vila

#### Aspectos a destacar:
*   Punteros a estructuras
