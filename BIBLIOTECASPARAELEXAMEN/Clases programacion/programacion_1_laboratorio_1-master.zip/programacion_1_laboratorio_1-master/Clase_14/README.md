# Clase 14

### Material

#### Apuntes:

En el directorio "apuntes" se podr�n encontrar los siguientes archivos:
* -

#### Video tutoriales:

* https://www.youtube.com/watch?v=vTPOx-gxBgg&index=14&list=PLZU3OfSJlsrfKiKElmKxjCsyQQF_1ApuV

### Ejercicio
#### Objetivo:

 Partiendo del ejercicio de la clase 13 incorporar la entidad AUTOR
 con los siguientes datos:

	    Datos del Autor:
           C�digo del Autor  (1 a 500)  Validar
           Nombre (m�ximo 50 caracteres)  Validar
          	Apellido (m�ximo 50 caracteres)  Validar

       ALTAS: No es necesario el ingreso de todos los autores.

       BAJA: Se ingresa el C�digo del autor

       LISTAR LIBROS:
           Realizar un solo listado con todos los libros, en el
           debera figurar el apellido del autor.

- Version: 0.1 del 04 enero de 2016
- Autor: Mauricio D�vila
- Revisi�n: Ernesto Gigliotti

#### Aspectos a destacar:
*   manejo de men� anidados
*   manejo de mas de una entidad
*   main() minimalista
*   sprintf